import React from "react";
import ReactDOM from "react-dom";
import RootComponent from "./root/root.component";
ReactDOM.render(React.createElement(RootComponent),document.querySelector("#root-container"));