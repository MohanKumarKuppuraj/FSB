import React from "react";
//import "./styles/selection.style.css";

class Selection extends React.Component{

	constructor(props){
		super(props);
	}

	componentDidMount(){

	}

	componentWillReceiveProps(){

	}

	render(){
		return (
			<div>Selection Component Loaded</div>
		);
	}

}

export default Selection;