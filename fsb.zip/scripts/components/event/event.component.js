import React from "react";
import Selection from "./../selection/selection.component";
//import "./styles/event.style.css";

class Event extends React.Component{

	constructor(props){
		super(props);
	}

	componentDidMount(){

	}

	componentWillReceiveProps(){

	}

	render(){
		return (
			<div>Event Component Loaded</div>
		);
	}

}

export default Event;